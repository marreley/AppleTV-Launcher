package com.appletv.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** Cinematic home top shelf, including an offline artwork fallback. */
class HeroView(context: Context, private val s: Scale) : FrameLayout(context) {
    private val classic = BuildConfig.FLAVOR == "classic"
    private val backgroundImage = ImageView(context).apply {
        scaleType = ImageView.ScaleType.CENTER_CROP
        setImageResource(if (classic) R.drawable.classic_landscape else R.drawable.cinematic_landscape)
    }
    private val overlay = View(context).apply {
        background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0x45000000, 0x1C050A15, 0xAA080C17.toInt(), 0xFF090B14.toInt()))
    }
    private val leftShadow = View(context).apply {
        background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(0xDB070D19.toInt(), 0x70070D19, 0x00070D19))
    }
    private val stack = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
    private val eyebrow = TextView(context).apply {
        text = if (classic) "APPLE TV · ACCUEIL" else "CINEMATIC · À LA UNE"
        setTextColor(0xD3FFFFFF.toInt())
        letterSpacing = .17f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        s.text(this, 21)
    }
    private val headline = TextView(context).apply {
        text = if (classic) "Vos apps. Votre télé." else "Votre écran.\nVotre cinéma."
        setTextColor(Color.WHITE)
        typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        s.text(this, if (classic) 74 else 82)
        maxLines = 2
        setShadowLayer(s.f(12), 0f, s.f(4), 0xAA000000.toInt())
    }
    private val subtitle = TextView(context).apply {
        text = if (classic) "Un accueil simple et fluide." else "Tout votre divertissement, à portée de télécommande."
        setTextColor(0xD5FFFFFF.toInt())
        s.text(this, 25)
        maxLines = 2
        ellipsize = TextUtils.TruncateAt.END
    }
    init {
        val heroH = s.px(790)
        addView(backgroundImage, LayoutParams(MATCH_PARENT, heroH))
        addView(overlay, LayoutParams(MATCH_PARENT, heroH))
        addView(leftShadow, LayoutParams(s.px(1230), heroH))
        stack.addView(eyebrow)
        stack.addView(headline, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = s.px(22) })
        stack.addView(subtitle, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = s.px(24) })
        addView(stack, LayoutParams(s.px(1080), WRAP_CONTENT, Gravity.TOP or Gravity.START).apply {
            leftMargin = s.px(if (classic) 110 else 100)
            topMargin = s.px(if (classic) 165 else 185)
        })
    }
    fun showApp(app: AppEntry) {
        // A focus change must not replace the whole home artwork with a giant app icon.
        // The selected app label is already displayed above the grid.
    }
    fun setAccent(accent: Int) {
        // Keep the cinematic artwork steady while navigating through apps.
    }
    fun showFeatured(item: Featured, backdropBitmap: Bitmap?, posterBitmap: Bitmap?) {
        if (backdropBitmap != null) backgroundImage.setImageBitmap(backdropBitmap)
        else backgroundImage.setImageResource(if (classic) R.drawable.classic_landscape else R.drawable.cinematic_landscape)
        eyebrow.text = "À LA UNE · ${item.subtitle}"
        headline.text = item.title
        subtitle.text = item.overview.ifBlank { "À découvrir" }
    }
}
