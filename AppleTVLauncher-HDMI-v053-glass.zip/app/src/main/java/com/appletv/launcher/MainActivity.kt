package com.appletv.launcher

import android.app.AlertDialog
import android.media.tv.TvContract
import android.media.tv.TvInputInfo
import android.media.tv.TvInputManager
import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.EditText
import android.text.InputType
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.core.app.ActivityOptionsCompat
import androidx.core.content.ContextCompat
import androidx.leanback.widget.HorizontalGridView
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var scale: Scale
    private lateinit var hero: HeroView
    private lateinit var sourceButton: TextView
    private lateinit var row: HorizontalGridView
    private lateinit var appLabel: TextView
    private lateinit var emptyView: TextView
    private lateinit var adapter: AppAdapter

    private val handler = Handler(Looper.getMainLooper())
    private var pendingHeroUpdate: Runnable? = null
    private var refreshJob: Job? = null
    private var heroJob: Job? = null
    private var selectedApp: AppEntry? = null
    private val catalogues = mutableMapOf<StreamingService, List<Featured>>()
    private val preferences by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }
    private val tmdbKey: String
        get() = preferences.getString("tmdb_key", null) ?: BuildConfig.TMDB_API_KEY
    private var receiverRegistered = false

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            refreshApps()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        scale = Scale(this)
        window.setBackgroundDrawable(ColorDrawable(0xFF080A10.toInt()))

        adapter = AppAdapter(scale, ::onAppFocused, ::launchApp, ::openAppInfo)
        setContentView(buildUi())

        // Retour : revient d'abord au premier élément, puis quitte vers l'accueil d'origine.
        onBackPressedDispatcher.addCallback(this) {
            if (row.selectedPosition > 0) {
                row.setSelectedPositionSmooth(0)
            } else {
                finish()
            }
        }

    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, packageReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        receiverRegistered = true
        refreshApps()
        selectedApp?.let(::onAppFocused)
    }

    override fun onStop() {
        if (receiverRegistered) {
            unregisterReceiver(packageReceiver)
            receiverRegistered = false
        }
        pendingHeroUpdate?.let(handler::removeCallbacks)
        heroJob?.cancel()
        super.onStop()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun buildUi(): View {
        val root = FrameLayout(this)
        val isClassic = BuildConfig.FLAVOR == "classic"
        root.clipChildren = false
        root.clipToPadding = false

        hero = HeroView(this, scale)
        root.addView(hero, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        // Heure et date, en haut à droite
        val clock = TextClock(this).apply {
            format24Hour = "HH:mm"
            format12Hour = "HH:mm"
            setTextColor(Color.WHITE)
            scale.text(this, 40)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            gravity = Gravity.END
        }
        val date = TextClock(this).apply {
            format24Hour = "EEEE d MMMM"
            format12Hour = "EEEE d MMMM"
            setTextColor(0xB3FFFFFF.toInt())
            scale.text(this, 22)
            gravity = Gravity.END
        }
        val topRight = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
            addView(clock, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT))
            addView(date, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT))
        }
        root.addView(
            topRight,
            FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.END).apply {
                topMargin = scale.px(48)
                marginEnd = scale.px(96)
            }
        )

        // Visible, remote-friendly HDMI input selector on both interface styles.
        sourceButton = TextView(this).apply {
            id = View.generateViewId()
            text = "▣  SOURCES  ·  HDMI / PS5"
            scale.text(this, 24)
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            gravity = Gravity.CENTER
            isFocusable = true
            isClickable = true
            setPadding(scale.px(25), scale.px(15), scale.px(25), scale.px(15))
            background = GradientDrawable().apply {
                cornerRadius = scale.f(24)
                setColor(0xB6283045.toInt())
                setStroke(scale.px(2).coerceAtLeast(1), 0x88FFFFFF.toInt())
            }
            setOnClickListener { showInputMenu() }
            setOnLongClickListener { showTmdbSettings(); true }
            setOnFocusChangeListener { _, focused ->
                animate().scaleX(if (focused) 1.07f else 1f)
                    .scaleY(if (focused) 1.07f else 1f).setDuration(150L).start()
            }
        }
        root.addView(sourceButton, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT,
            Gravity.TOP or Gravity.START).apply {
            leftMargin = scale.px(100)
            topMargin = scale.px(46)
        })

        // Cinematic: two rows; Classic: a restrained single app dock.
        val dock = FrameLayout(this).apply {
            if (isClassic) {
                background = GradientDrawable().apply {
                    cornerRadius = scale.f(30)
                    setColor(0x142D3038)
                    setStroke(scale.px(1).coerceAtLeast(1), 0x31FFFFFF)
                }
            } else {
                background = GradientDrawable(
                    GradientDrawable.Orientation.TOP_BOTTOM,
                    intArrayOf(0x8033202B.toInt(), 0xD9121019.toInt())
                ).apply {
                    cornerRadius = scale.f(22)
                    setStroke(scale.px(2).coerceAtLeast(1), 0x62DEEFFF)
                }
            }
        }
        root.addView(dock, FrameLayout.LayoutParams(MATCH_PARENT, scale.px(if (isClassic) 255 else 390), Gravity.BOTTOM).apply {
            leftMargin = scale.px(if (isClassic) 85 else 72)
            rightMargin = scale.px(if (isClassic) 85 else 72)
            bottomMargin = scale.px(if (isClassic) 64 else 22)
        })

        row = HorizontalGridView(this).apply {
            if (!isClassic) setNumRows(2)
            adapter = this@MainActivity.adapter
            itemAnimator = null
            setHasFixedSize(true)
            setItemSpacing(scale.px(if (isClassic) 30 else 26))
            clipChildren = false
            clipToPadding = false
            setPadding(scale.px(36), scale.px(18), scale.px(36), scale.px(24))
        }
        row.id = View.generateViewId()
        row.nextFocusUpId = sourceButton.id
        sourceButton.nextFocusDownId = row.id
        dock.addView(row, FrameLayout.LayoutParams(MATCH_PARENT, scale.px(if (isClassic) 193 else 317), Gravity.BOTTOM).apply {
            bottomMargin = scale.px(12)
        })

        // Nom de l'application sélectionnée
        appLabel = TextView(this).apply {
            scale.text(this, 30)
            setTextColor(0xE6FFFFFF.toInt())
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            maxLines = 1
        }
        dock.addView(
            appLabel,
            FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.START).apply {
                leftMargin = scale.px(45)
                topMargin = scale.px(17)
            }
        )

        emptyView = TextView(this).apply {
            text = "Aucune application détectée"
            scale.text(this, 30)
            setTextColor(0x99FFFFFF.toInt())
            visibility = View.GONE
        }
        root.addView(
            emptyView,
            FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
                bottomMargin = scale.px(220)
            }
        )

        return root
    }

    /** Public TV input APIs can open some manufacturer HDMI inputs; they cannot guarantee switching. */
    private fun showInputMenu() {
        val choices = arrayOf("HDMI 1", "HDMI 2", "HDMI 3", "Sources / Paramètres TCL", "Configurer TMDB")
        AlertDialog.Builder(this)
            .setTitle("Choisir une source TV")
            .setItems(choices) { _, selected ->
                when (selected) {
                    3 -> openSystemSources()
                    4 -> showTmdbSettings()
                    else -> tryHdmi(selected + 1)
                }
            }
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun tryHdmi(port: Int) {
        try {
            val manager = getSystemService(Context.TV_INPUT_SERVICE) as TvInputManager
            val portLabel = Regex("HDMI[\\s-]*$port", RegexOption.IGNORE_CASE)
            val matching = manager.tvInputList.singleOrNull { input ->
                input.type == TvInputInfo.TYPE_HDMI &&
                    portLabel.matches(input.loadLabel(this).toString().trim())
            }
            if (matching != null) {
                val intent = Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput(matching.id))
                startActivity(intent)
                return
            }
        } catch (_: Exception) {
            // Some TCL firmware reserves HDMI switching for the privileged TV interface.
        }
        AlertDialog.Builder(this)
            .setTitle("HDMI $port")
            .setMessage("Cette TCL ne permet pas de basculer directement vers HDMI $port depuis ce launcher. Ouvre Sources dans le menu TCL ou utilise la touche Source de la télécommande.")
            .setPositiveButton("Ouvrir les paramètres") { _, _ -> openSystemSources() }
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun openSystemSources() {
        // Settings is a dependable fallback; input selection is device-specific.
        try {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        } catch (_: Exception) {
            toast("Appuie sur Source / Input sur la télécommande TCL")
        }
    }

    private fun refreshApps() {
        refreshJob?.cancel()
        refreshJob = lifecycleScope.launch {
            val list = AppRepository.load(applicationContext)
            val firstLoad = adapter.itemCount == 0
            adapter.submitList(list) {
                emptyView.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                if (firstLoad && list.isNotEmpty()) {
                    row.post { row.requestFocus() }
                }
            }
        }
    }

    /** Appelé à chaque changement de sélection dans la rangée. */
    private fun onAppFocused(app: AppEntry) {
        selectedApp = app
        appLabel.text = app.label
        pendingHeroUpdate?.let(handler::removeCallbacks)
        heroJob?.cancel()
        val update = Runnable {
            hero.showApp(app)
            val service = StreamingService.forApp(app)
            val key = tmdbKey
            if (service != null && key.isNotBlank()) {
                heroJob = lifecycleScope.launch {
                    val items = catalogues[service] ?: FeaturedRepository.fetch(service, key).also {
                        if (it.isNotEmpty()) catalogues[service] = it
                    }
                    if (items.isEmpty()) return@launch
                    var index = 0
                    while (true) {
                        val item = items[index]
                        val backdrop = ImageLoader.load(item.backdropUrl)
                        if (backdrop != null) hero.showFeatured(item, backdrop, items, index)
                        delay(HERO_INTERVAL_MS)
                        index = (index + 1) % items.size
                    }
                }
            }
        }
        pendingHeroUpdate = update
        handler.postDelayed(update, HERO_DEBOUNCE_MS)
    }

    private fun showTmdbSettings() {
        val input = EditText(this).apply {
            hint = "Clé API v3 ou jeton de lecture"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
        }
        AlertDialog.Builder(this)
            .setTitle("Catalogue TMDB France")
            .setView(input)
            .setPositiveButton("Enregistrer") { _, _ ->
                val key = input.text.toString().trim()
                if (key.isNotBlank()) updateTmdbKey(key)
            }
            .setNeutralButton("Effacer") { _, _ -> updateTmdbKey("") }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun updateTmdbKey(key: String) {
        preferences.edit().putString("tmdb_key", key).apply()
        catalogues.clear()
        selectedApp?.let(::onAppFocused)
    }

    private fun launchApp(app: AppEntry, view: View) {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            component = app.component
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        }
        try {
            val options = ActivityOptionsCompat.makeScaleUpAnimation(view, 0, 0, view.width, view.height)
            startActivity(intent, options.toBundle())
        } catch (e: ActivityNotFoundException) {
            toast("Impossible d'ouvrir ${app.label}")
        } catch (e: SecurityException) {
            toast("Impossible d'ouvrir ${app.label}")
        }
    }

    private fun openAppInfo(app: AppEntry) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:${app.packageName}")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            toast("Informations indisponibles pour ${app.label}")
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private companion object {
        const val HERO_INTERVAL_MS = 9_000L
        const val HERO_DEBOUNCE_MS = 140L
    }
}
