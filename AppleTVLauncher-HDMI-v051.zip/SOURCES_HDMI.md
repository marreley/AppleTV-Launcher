# Sources HDMI (Cinematic et Apple TV Classic)

Un bouton **SOURCES · HDMI / PS5** apparaît en haut à gauche sur les deux interfaces. Accessible à la télécommande avec la touche Haut depuis le dock, puis OK. Il ouvre un menu HDMI 1/2/3 et Paramètres TCL.

Le launcher essaie de lancer la source HDMI à l’aide des API Android TV publiques si la TCL expose une entrée libellée HDMI 1, 2 ou 3 et un lecteur compatible. **Le changement HDMI direct n’est pas garanti** : les fabricants peuvent réserver cette fonction à leur interface système. Dans ce cas, une explication et un bouton vers Paramètres s’affichent, et la touche Source / Input de la télécommande reste la voie sûre.

**PS5** : branche-la au port souhaité et choisis son numéro HDMI. L’application ne détecte pas automatiquement à quel port la PS5 est branchée et ne promet pas de démarrer la console.

Compilation GitHub Actions : deux APK distincts `cinematicDebug` et `classicDebug`. Aucun des deux ne remplace le launcher Google TV d’origine.
