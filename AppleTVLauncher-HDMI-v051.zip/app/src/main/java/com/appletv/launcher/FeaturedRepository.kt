package com.appletv.launcher

import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class Featured(val title: String, val subtitle: String, val overview: String, val backdropUrl: String)

data class StreamingService(val name: String, val providerId: Int) {
    companion object {
        fun forApp(app: AppEntry): StreamingService? = when (app.packageName) {
            "com.netflix.ninja", "com.netflix.mediaclient" -> StreamingService("Netflix", 8)
            "com.amazon.amazonvideo.livingroom", "com.amazon.avod.thirdpartyclient" -> StreamingService("Prime Video", 119)
            "com.disney.disneyplus" -> StreamingService("Disney+", 337)
            "com.apple.atve.androidtv.appletv", "com.apple.atve.androidtv.appletvplus" -> StreamingService("Apple TV", 350)
            "com.canal.android.canal" -> StreamingService("CANAL+", 381)
            else -> null
        }
    }
}

object FeaturedRepository {
    suspend fun fetch(service: StreamingService, key: String): List<Featured> = withContext(Dispatchers.IO) {
        if (key.isBlank()) return@withContext emptyList()
        val films = discover("movie", service, key)
        val series = discover("tv", service, key)
        (0 until maxOf(films.size, series.size)).flatMap { index ->
            listOfNotNull(films.getOrNull(index), series.getOrNull(index))
        }
    }

    private fun discover(type: String, service: StreamingService, key: String): List<Featured> {
        val endpoint = Uri.parse("https://api.themoviedb.org/3/discover/$type").buildUpon()
            .appendQueryParameter("language", "fr-FR")
            .appendQueryParameter("watch_region", "FR")
            .appendQueryParameter("with_watch_providers", service.providerId.toString())
            .appendQueryParameter("with_watch_monetization_types", "flatrate")
            .appendQueryParameter("include_adult", "false")
            .appendQueryParameter("sort_by", "popularity.desc")
        val bearer = key.contains('.')
        if (!bearer) endpoint.appendQueryParameter("api_key", key)
        val connection = URL(endpoint.build().toString()).openConnection() as HttpURLConnection
        return try {
            connection.connectTimeout = 6_000
            connection.readTimeout = 6_000
            if (bearer) connection.setRequestProperty("Authorization", "Bearer $key")
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val results = JSONObject(body).getJSONArray("results")
            (0 until results.length()).mapNotNull { index ->
                val item = results.getJSONObject(index)
                val backdrop = item.optString("backdrop_path")
                val movie = type == "movie"
                val title = item.optString(if (movie) "title" else "name")
                if (!backdrop.startsWith("/") || title.isBlank()) return@mapNotNull null
                Featured(title, "${service.name} · ${if (movie) "Film" else "Série"}",
                    item.optString("overview"), "https://image.tmdb.org/t/p/w1280$backdrop")
            }.take(4)
        } catch (_: IOException) {
            emptyList()
        } catch (_: org.json.JSONException) {
            emptyList()
        } finally {
            connection.disconnect()
        }
    }
}
