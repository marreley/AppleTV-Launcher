package com.appletv.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** Cinematic home top shelf, including an offline artwork fallback. */
class HeroView(context: Context, private val s: Scale) : FrameLayout(context) {
    private val artwork = ImageView(context).apply {
        scaleType = ImageView.ScaleType.FIT_CENTER
        visibility = GONE
    }
    private val indicator = TextView(context).apply {
        setTextColor(0xCCFFFFFF.toInt())
        s.text(this, 19)
        visibility = GONE
    }
    private val classic = BuildConfig.FLAVOR == "classic"
    private val backgroundImage = ImageView(context).apply {
        scaleType = ImageView.ScaleType.CENTER_CROP
        setImageResource(if (classic) R.drawable.classic_landscape else R.drawable.cinematic_landscape)
    }
    private val overlay = View(context).apply {
        background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0x45000000, 0x1C050A15, 0xAA080C17.toInt(), 0xB0090B14.toInt()))
    }
    private val leftShadow = View(context).apply {
        background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(0xDB070D19.toInt(), 0x70070D19, 0x00070D19))
    }
    private val stack = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
    private val eyebrow = TextView(context).apply {
        text = ""
        setTextColor(0xD3FFFFFF.toInt())
        letterSpacing = .17f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        s.text(this, 21)
    }
    private val headline = TextView(context).apply {
        text = "Applications"
        setTextColor(Color.WHITE)
        typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        s.text(this, if (classic) 74 else 82)
        maxLines = 2
        setShadowLayer(s.f(12), 0f, s.f(4), 0xAA000000.toInt())
    }
    private val subtitle = TextView(context).apply {
        text = ""
        setTextColor(0xD5FFFFFF.toInt())
        s.text(this, 25)
        maxLines = 2
        ellipsize = TextUtils.TruncateAt.END
    }
    init {
        val heroH = MATCH_PARENT
        addView(backgroundImage, LayoutParams(MATCH_PARENT, heroH))
        addView(overlay, LayoutParams(MATCH_PARENT, heroH))
        addView(leftShadow, LayoutParams(s.px(1230), heroH))
        addView(artwork, LayoutParams(s.px(690), s.px(346), Gravity.TOP or Gravity.END).apply {
            marginEnd = s.px(112)
            topMargin = s.px(182)
        })
        stack.addView(eyebrow)
        stack.addView(headline, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = s.px(22) })
        stack.addView(subtitle, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = s.px(24) })
        stack.addView(indicator)
        addView(stack, LayoutParams(s.px(if (classic) 890 else 820), WRAP_CONTENT, Gravity.TOP or Gravity.START).apply {
            leftMargin = s.px(if (classic) 110 else 100)
            topMargin = s.px(if (classic) 165 else 185)
        })
    }
    fun showApp(app: AppEntry) {
        if (classic) backgroundImage.setImageResource(R.drawable.classic_landscape)
        else backgroundImage.setImageResource(R.drawable.cinematic_landscape)
        artwork.setImageBitmap(app.banner ?: app.icon)
        artwork.visibility = VISIBLE
        indicator.visibility = GONE
        eyebrow.contentDescription = null
        eyebrow.text = ""
        headline.text = app.label
        subtitle.text = ""
    }

    fun showFeatured(item: Featured, backdrop: Bitmap, items: List<Featured>, index: Int) {
        backgroundImage.setImageBitmap(backdrop)
        artwork.visibility = GONE
        eyebrow.text = item.subtitle
        headline.text = item.title
        val progress = items.indices.joinToString("  ") { if (it == index) "●" else "○" }
        subtitle.text = item.overview.take(155)
        eyebrow.contentDescription = "${item.subtitle}, ${index + 1} sur ${items.size}"
        indicator.text = progress
        indicator.visibility = VISIBLE
    }
}
