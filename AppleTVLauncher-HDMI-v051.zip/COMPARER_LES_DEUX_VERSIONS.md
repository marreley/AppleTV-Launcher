# Comparer Cinematic et Apple TV Style sur la TCL 43P635

Le projet contient maintenant **deux variantes Android installables côte à côte** :

- `cinematicDebug` : grand fond cinématographique, dock sombre à deux rangées.
- `classicDebug` : accueil plus minimaliste inspiré de tvOS, dock à une rangée.

Les identifiants Android diffèrent (`com.appletv.launcher.cinematic` et `com.appletv.launcher.classic`). Ils ne remplacent pas la version installée sous `com.appletv.launcher`, ni l'accueil Google TV.

## Compiler sur GitHub Actions

Importer **le contenu** de ce dossier à la racine du dépôt GitHub, en conservant `.github/workflows/build.yml`, puis lancer **Build debug APK** dans Actions. Le workflow compile les deux variantes et produit un artefact ZIP contenant les deux APK.

## Remarque

Les variantes sont des prototypes fonctionnels proposés à la compilation, pas encore testés sur la TCL. Sans secret TMDB, les deux écrans conservent leur fond intégré ; aucune jaquette de film réelle n'est fournie automatiquement.
