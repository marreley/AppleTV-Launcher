# AppleTV Launcher — v0.2 cinematic update

This update replaces the empty purple screen and giant app tile with a bundled cinematic background, layered translucent two-row dock, rounded app tiles, and remote-control navigation. All images for the default home are local, so **no TMDB key is required**. If configured, TMDB still populates the featured film header.

## Build with GitHub Actions

Upload all files from this archive into the root of your existing GitHub repository (preserve `.github` and `gradle` directories). Commit to `main`; open **Actions → Build debug APK → latest successful run → Artifacts**. Download and unzip `AppleTVLauncher-debug-apk`, then transfer the APK to your TCL TV. The original Google TV launcher remains unchanged.

**Not yet compiled or tested on a TCL television.** Source code is provided for cloud build. This is a tvOS-inspired design, not Apple software.
